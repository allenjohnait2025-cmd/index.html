# CyberAI — AI in Cybersecurity

A browser-based educational project demonstrating:
- Phishing message checking (rule-based demo)
- Login anomaly scoring (heuristic demo)
- Cybersecurity FAQ assistant (local FAQ knowledge base)
- Research themes in AI and cybersecurity

## Run the project
1. Extract `CyberAI_Project.zip`.
2. Open the `CyberAI_Project` folder.
3. Double-click `index.html` to open it in a web browser.

No server or installation is required for this single-file demo.

## Important
This is an educational demonstration, not a production security product. The scores are illustrative and the FAQ assistant uses built-in answers rather than a live generative AI model.
